import React from "react"

function Header() {
    return (
    <header>
        <img src="images/yanaworks.png" className="logo"></img>
    </header>

    )
        
    
}

export default Header